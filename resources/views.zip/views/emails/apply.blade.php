<!DOCTYPE html>
  <html>
  <head>
    <title></title>
    <style type="text/css">
      #greet{
        background: seagreen;
        color:white;
        font-family: monospace;
        padding: 20px;
        text-align: center;
      }
    </style>
  </head>
  <body>
      <h2 id="greet">Hello</h2>
  </body>
  </html>