
    @include('layout.headingsectionwithoutimage')
    <link rel="stylesheet" href="{{asset('assets/css/nice-select.css')}}">
    <!-- You can use Open Graph tags to customize link previews.
    Learn more: https://developers.facebook.com/docs/sharing/webmasters -->
    <meta property="og:url"           content="https://www.karmondana.com/scholarship/{{$scholarship->id}}" />
    <meta property="og:type"          content="website" />
    <meta property="og:title"         content="{{$scholarship->name}}" />
    <meta property="og:description"   content="{{$scholarship->name}}" />
    <meta property="og:image"         content="https://www.karmondana.com/assets/images/logogreenfacebook.png" />

    <title>Scholarship Details</title>
    <style>
        body {
            background: rgb(245,245,245);
        }
        #scholarshipdetailscontainer,
        #scholarshipdetailrightside{
            background:white;
            border-radius:5px;
        }
        .eachattribute{
            border-top: 1px solid lightgray;
            font-size:15px;
            padding-top: 12px;
            padding-bottom: 12px;
        }
        .eatchattributedata{
            color:#999;
            text-transform: capitalize;
        }
        .topandbottomsections{
            padding:30px;
        }
        .fa-heart{
            font-size:20px
        }
    </style>
    @include('layout.fieldsets')
    @include('layout.globalfontsize')
    @include('layout.headersectionwithoutimage')

    <!-- Jobs Area Starts -->
    <section class="jobs-area section-padding">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
                    <!-- karsq -->
                    <ins class="adsbygoogle"
                        style="display:inline-block;width:100%;height:300px"
                        data-ad-client="ca-pub-8480911180475311"
                        data-ad-slot="6038209487"></ins>
                    <script>
                        (adsbygoogle = window.adsbygoogle || []).push({});
                    </script>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-9 col-md-8 shadow-sm p-0" id="scholarshipdetailscontainer">
                    <div class="topandbottomsections">
                        <div class="row d-sm-flex">
                            <div class="align-self-center flex-fill">
                                <h4 class="text-success font-weight-bold">{{$scholarship->name}}</h4>
                                <span class="text-capitalize">{{$scholarship->country}}</span> / <span class="text-capitalize text-danger">{{$scholarship->closingdate}}</span>
                                <br>
                                
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-12">
                                <script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
                                <!-- karsq -->
                                <ins class="adsbygoogle"
                                    style="display:inline-block;width:100%;height:300px"
                                    data-ad-client="ca-pub-8480911180475311"
                                    data-ad-slot="6038209487"></ins>
                                <script>
                                    (adsbygoogle = window.adsbygoogle || []).push({});
                                </script>
                            </div>
                        </div>
                    </div>
                    <div class="topandbottomsections">
                        @if($scholarship->briefdescription !="N/A")
                            <h4 class="text-success font-weight-normal mt-5">Brief Description</h4>
                            <p>{!!$scholarship->briefdescription!!}</p>
                        @endif
                        @if($scholarship->about !="N/A")
                            <h4 class="text-success font-weight-normal">About University</h4>
                            <p>{!!$scholarship->about!!}</p>
                        @endif
                        @if(isset($scholarship->scholarshiptype[0]))
                        <h4 class="text-success font-weight-normal mt-5">Scholarship Type</h4>
                            @foreach($scholarship->scholarshiptype as $type)
                                {{$type->type}} <br>
                            @endforeach
                        @endif
                        <h4 class="text-success font-weight-normal mt-5">Fields of study</h4>
                        <p>{!!$scholarship->fields!!}</p>

                        @if(isset($scholarship->scholarshipdegree[0]))
                        <h4 class="text-success font-weight-normal mt-5">Degrees</h4>
                            @foreach($scholarship->scholarshipdegree as $degree)
                                {{$degree->degree}} <br>
                            @endforeach
                        @endif
                        <h4 class="text-success font-weight-normal mt-5">Scholarship Details</h4>
                        <div class="col-12">
                            <script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
                            <!-- karsq -->
                            <ins class="adsbygoogle"
                                style="display:inline-block;width:100%;height:300px"
                                data-ad-client="ca-pub-8480911180475311"
                                data-ad-slot="6038209487"></ins>
                            <script>
                                (adsbygoogle = window.adsbygoogle || []).push({});
                            </script>
                        </div>
                        <p>{!!$scholarship->scholarshipdetails!!}</p>
                        <h4 class="text-success font-weight-normal mt-5">Who Can Apply</h4>
                        <p>{!!$scholarship->whocanapply!!}</p>
                        <h4 class="text-success font-weight-normal mt-5">Application Link</h4>
                        <div class="d-block">
                            <script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
                            <!-- karsq -->
                            <ins class="adsbygoogle"
                                style="display:inline-block;width:100%;height:300px"
                                data-ad-client="ca-pub-8480911180475311"
                                data-ad-slot="6038209487"></ins>
                            <script>
                                (adsbygoogle = window.adsbygoogle || []).push({});
                            </script>
                        </div>
                        
                        <a href="#"  onclick="event.preventDefault();document.getElementById('scholarshipoutside').submit();" class="btn btn-success pl-5 pr-5 btn-sm">Apply</a>
                        <form id="scholarshipoutside" action="{{ route('scholarshipoutside') }}" method="POST" style="display: none;">
                            <input type="text" value="{{$scholarship->link}}" name="link">
                            @csrf
                        </form>
                    </div>
                    <div class="mt-5"> Share &nbsp&nbsp
                          <!-- Load Facebook SDK for JavaScript -->
                            <div id="fb-root"></div>
                            <script>(function(d, s, id) {
                                var js, fjs = d.getElementsByTagName(s)[0];
                                if (d.getElementById(id)) return;
                                js = d.createElement(s); js.id = id;
                                js.src = "https://connect.facebook.net/en_US/sdk.js#xfbml=1&version=v3.0";
                                fjs.parentNode.insertBefore(js, fjs);
                            }(document, 'script', 'facebook-jssdk'));</script>

                            <!-- Your share button code -->
                            <div class="fb-share-button" 
                                data-href="https://www.karmondana.com/scholarship/{{$scholarship->id}}" 
                                data-layout="button_count">
                            </div>
                        </div>
                </div>
                <div class="col-lg-3 col-md-4 shadow-sm p-3 mt-5 mt-md-0" id="scholarshipdetailrightside">
                    <div id="relatedjobscontainer" class="pt-0">
                        <fieldset class="fieldsets p-3 rounded">
                            <legend class="w-auto pl-3 pr-3">You may also like</legend>
                            @if(isset($related[0]))
                                @php($counter = 1)
                                @foreach($related as $rel)
                                    <div class="eachrelatedjob pt-2 pb-2 border-bottom">
                                        <a href="{{route('book.show', $rel->id)}}" class="text-success">{{$rel->name}}</a>
                                    </div>
                                    @php($counter++)
                                    @if($counter >= 10)
                                        @break
                                    @endif
                                @endforeach
                            @else
                                <h6>No Related Scholarships</h6>
                            @endif
                        </fieldset>
                    </div>
                    <div id="rightsidead1" class="">
                        <fieldset class="fieldsets p-3 rounded">
                            <legend class="w-auto pl-3 pr-3">Advertisement</legend>

                            <script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
                            <!-- 300*250 -->
                            <ins class="adsbygoogle"
                                style="display:inline-block;width:100%;height:250px"
                                data-ad-client="ca-pub-8480911180475311"
                                data-ad-slot="1676292648"></ins>
                            <script>
                                (adsbygoogle = window.adsbygoogle || []).push({});
                            </script>

                            
                            <script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
                            <!-- kar 300*600 -->
                            <ins class="adsbygoogle"
                                style="display:inline-block;width:100%;height:600px"
                                data-ad-client="ca-pub-8480911180475311"
                                data-ad-slot="3148731385"></ins>
                            <script>
                                (adsbygoogle = window.adsbygoogle || []).push({});
                            </script>
                        </fieldset>
                        
                    </div>
                    <fieldset class="fieldsets p-3 rounded">
                        <legend class="w-auto pl-3 pr-3">Facebook</legend>
                        <iframe src="https://www.facebook.com/plugins/page.php?href=https%3A%2F%2Fwww.facebook.com%2Fkarmondana&tabs=timeline&width=340&height=500&small_header=false&adapt_container_width=true&hide_cover=false&show_facepile=true&appId" width="100%" height="200" style="border:none;overflow:hidden" scrolling="no" frameborder="0" allowTransparency="true" allow="encrypted-media"></iframe>
                    </fieldset>
                </div>
            </div>
        </div>
    </section>
    
    <div class="container">
        <div class="row">
            <div class="col-12">
                <script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
                <!-- karsq -->
                <ins class="adsbygoogle"
                    style="display:inline-block;width:100%;height:300px"
                    data-ad-client="ca-pub-8480911180475311"
                    data-ad-slot="6038209487"></ins>
                <script>
                    (adsbygoogle = window.adsbygoogle || []).push({});
                </script>
            </div>
        </div>
    </div>
    <!-- Jobs Area End -->


    @include('layout.footersection')
    <script src="{{asset('assets/js/vendor/sweetalert.min.js')}}"></script>
    <script>
        $('#locationsearch, #categorysearch').select2();
    </script>
    @include('layout.sessionmessage')
