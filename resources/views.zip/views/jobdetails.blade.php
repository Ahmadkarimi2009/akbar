    @include('layout.headingsectionwithoutimage')
    <link rel="stylesheet" href="{{asset('assets/css/nice-select.css')}}">
    <!-- You can use Open Graph tags to customize link previews.
    Learn more: https://developers.facebook.com/docs/sharing/webmasters -->




    <title>Job Details</title>
    <style>
        body {
            background: rgb(245,245,245);
        }
        #jobdetailscontainer, #jobdetailsrightside{
            background:white;
            border-radius:5px;
        }
        .eachattribute{
            border-top: 1px solid lightgray;
            font-size:15px;
            padding-top: 12px;
            padding-bottom: 12px;
        }
        .eatchattributedata{
            color:#999;
            text-transform: capitalize;
        }
        .topandbottomsections{
            padding:30px;
        }
        .fa-heart{
            font-size:20px
        }
    
    #rightsidelogincontainer{
        box-shadow: 0px 0px 5px lightgray inset;
    }

    </style>
    @include('layout.fieldsets')
    @include('layout.globalfontsize')
    @include('layout.headersectionwithoutimage')
    @foreach($job as $jobb)
    <!-- Jobs Area Starts -->
    <div class="container">
        <div class="row">
            <div class="col-12">
                <script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
                <!-- karsq -->
                <ins class="adsbygoogle"
                    style="display:inline-block;width:100%;height:300px"
                    data-ad-client="ca-pub-8480911180475311"
                    data-ad-slot="6038209487"></ins>
                <script>
                    (adsbygoogle = window.adsbygoogle || []).push({});
                </script>
            </div>
            
        </div>
    </div>
    <section class="jobs-area section-padding mt-3">
        <div class="container">
            <div class="row">
                <div class="col-lg-9 col-md-8 shadow-sm p-0" id="jobdetailscontainer">
                    <div class="topandbottomsections">
                        <div class="row">
                            <div class="col-12 text-center">
                            @if($jobb->company->user_id != 0)
                                <div class="d-inline-block pr-2 align-self-center">
                                    <img src="{{asset($jobb->company->user->avatar)}}" width="100px" height="100px">
                                </div>
                            @else
                                <div class="d-inline-block pr-2 align-self-center">
                                    <img src="{{asset('assets/avatars/company.png')}}" alt="job" width="100px" height="100px" class="rounded-circle mt-2">
                                </div>
                            @endif
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-12 text-center mt-3">
                                <div class="align-self-center flex-fill">
                                    <h4 class="text-success font-weight-bold">{{$jobb->title}}</h4>
                                    <h6 class="text-capitalize">{{$jobb->company->name}}</h6>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-12">
                                <script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
                                <!-- karsq -->
                                <ins class="adsbygoogle"
                                    style="display:inline-block;width:100%;height:300px"
                                    data-ad-client="ca-pub-8480911180475311"
                                    data-ad-slot="6038209487"></ins>
                                <script>
                                    (adsbygoogle = window.adsbygoogle || []).push({});
                                </script>
                            </div>
                            
                        </div>
                    </div>
                    <div class="topandbottomsections">
                        <div class="row">
                            <div class="col-sm-6">
                                <div class="row eachattribute border-0">
                                    <span class="col-6 text-dark">Starting Date</span>
                                    <span class="col-6 eatchattributedata">{{$jobb->openingdate}}</span>
                                </div>
                            </div>
                            <div class="col-sm-6">
                                <div class="row eachattribute border-0">
                                    <span class="col-6 text-dark">Closing Date</span>
                                    <span class="col-6 eatchattributedata text-danger">{{$jobb->closingdate}}</span>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-sm-6 eachattribute">
                                <div class="row">
                                    <span class="col-6 text-dark">Vacancy Number</span>
                                    <span class="col-6 eatchattributedata">{{$jobb->vacancynumber}}</span>
                                </div>
                            </div>
                            <div class="col-sm-6">
                                <div class="row eachattribute">
                                    <span class="col-6 text-dark">Category</span>
                                    <span class="col-6 eatchattributedata">{{$jobb->jobcategory->name}}</span>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-sm-6 eachattribute">
                                <div class="row">
                                    <span class="col-6 text-dark">Gender</span>
                                    <span class="col-6 eatchattributedata">{{$jobb->gender}}</span>
                                </div>
                            </div>
                            <div class="col-sm-6">
                                <div class="row eachattribute">
                                    <span class="col-6 text-dark">Nationality</span>
                                    <span class="col-6 eatchattributedata">{{$jobb->nationality}}</span>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-sm-6 eachattribute">
                                <div class="row">
                                    <span class="col-6 text-dark">Salary</span>
                                    <span class="col-6 eatchattributedata">{{$jobb->salary}}</span>
                                </div>
                            </div>
                            <div class="col-sm-6">
                                <div class="row eachattribute">
                                    <span class="col-6 text-dark">Number of Job</span>
                                    <span class="col-6 eatchattributedata">{{$jobb->numberofjobs}}</span>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-sm-6 eachattribute">
                                <div class="row">
                                    <span class="col-6 text-dark">Contract Type</span>
                                    <span class="col-6 eatchattributedata">{{$jobb->contracttype}}</span>
                                </div>
                            </div>
                            <div class="col-sm-6">
                                <div class="row eachattribute">
                                    <span class="col-6 text-dark">Contract Duration</span>
                                    <span class="col-6 eatchattributedata">{{$jobb->contractduration}}</span>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-sm-6">
                                <div class="row eachattribute">
                                    <span class="col-6 text-dark">Work Type</span>
                                    <span class="col-6 eatchattributedata">{{$jobb->worktype}}</span>
                                </div>
                            </div>
                            <div class="col-sm-6">
                                <div class="row eachattribute">
                                    <span class="col-6 text-dark">Work Experience</span>
                                    <span class="col-6 eatchattributedata">{{$jobb->experienceyears}}</span>
                                </div>
                            </div>
                        </div>
                        <div class="col-12">
                            <script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
                            <!-- karsq -->
                            <ins class="adsbygoogle"
                                style="display:inline-block;width:100%;height:300px"
                                data-ad-client="ca-pub-8480911180475311"
                                data-ad-slot="6038209487"></ins>
                            <script>
                                (adsbygoogle = window.adsbygoogle || []).push({});
                            </script>
                        </div>
                    </div>
                    <div class="topandbottomsections">
                        <h4 class="font-weight-normal">About {{$jobb->company->name}}</h4>
                        <p>{!!  $jobb->aboutcompany!!}</p>

                        <h4 class="font-weight-normal mt-5">Job Description</h4>
                        <p>{!!$jobb->responsibilities!!}</p>

                        <h4 class="font-weight-normal mt-5">Qualifications</h4>
                        <div class="row">
                            <div class="col-12">
                                <script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
                                <!-- karsq -->
                                <ins class="adsbygoogle"
                                    style="display:inline-block;width:100%;height:300px"
                                    data-ad-client="ca-pub-8480911180475311"
                                    data-ad-slot="6038209487"></ins>
                                <script>
                                    (adsbygoogle = window.adsbygoogle || []).push({});
                                </script>
                            </div>
                        </div>
                        <p>{!!$jobb->qualifications!!}</p>

                        @if(isset($jobb->jobskill[0]))
                            <h4 class=" font-weight-normal mt-5">Skills Required</h4>
                            @foreach($jobb->jobskill as $skill)
                                {{$skill->skill}} , 
                            @endforeach
                        @endif

                        @if(isset($jobb->joblanguage[0]))
                            <h4 class=" font-weight-normal mt-5">Languges Required</h4>
                            @foreach($jobb->joblanguage as $lang)
                                {{$lang->language}} , 
                            @endforeach
                        @endif


                        <h4 class=" font-weight-normal mt-5">Submission Guidlines</h4>
                        <p>{!!$jobb->guide!!}</p>

                        <h4 class=" font-weight-normal mt-5">Submission Email(s)</h4>
                        @if(isset($jobb->jobemail[0]))
                            @foreach($jobb->jobemail as $email)
                                <span class="pr-2">{{$email->email}}</span>
                            @endforeach
                        @endif

                        @if($jobb->file !="N/A")
                            <h4 class=" font-weight-normal mt-5">File(s)</h4>
                            <button onclick="$('#downloadingform').submit()" class="btn btn-outline-success btn-sm  pl-3 pr-3">Download File</button>

                            <form class="d-none" method="post" action="{{route('downloadfile')}}" id="downloadingform">
                                @csrf
                                <input value="{{$jobb->file}}" name="filepath">
                            </form>
                        @endif
                        <br>

                        <div class="d-block">
                            <script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
                            <!-- karsq -->
                            <ins class="adsbygoogle"
                                style="display:inline-block;width:100%;height:300px"
                                data-ad-client="ca-pub-8480911180475311"
                                data-ad-slot="6038209487"></ins>
                            <script>
                                (adsbygoogle = window.adsbygoogle || []).push({});
                            </script>
                        </div>
                        <a href="{{url('jobapplication', $jobb->id)}}" class="btn btn-success pr-5 btn-sm pl-5 mt-5">Apply</a>



                        <div class="mt-5"> Share &nbsp&nbsp

                          <!-- Load Facebook SDK for JavaScript -->
                            <div id="fb-root"></div>
                            <script>(function(d, s, id) {
                                var js, fjs = d.getElementsByTagName(s)[0];
                                if (d.getElementById(id)) return;
                                js = d.createElement(s); js.id = id;
                                js.src = "https://connect.facebook.net/en_US/sdk.js#xfbml=1&version=v3.0";
                                fjs.parentNode.insertBefore(js, fjs);
                            }(document, 'script', 'facebook-jssdk'));</script>

                            <!-- Your share button code -->
                            <div class="fb-share-button" 
                                data-href="https://www.karmondana.com/jobs/{{$job[0]->id}}" 
                                data-layout="button_count">
                            </div>


                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-4 shadow-sm p-2 mt-5 mt-md-0" id="jobdetailsrightside">

                    <div id="relatedjobscontainer" class="pt-0">
                        <fieldset class="fieldsets p-3 rounded">
                            <legend class="w-auto pl-3 pr-3">You may also like</legend>
                            @if(isset($related[0]))
                                @php($counter = 1)
                                @foreach($related as $rel)
                                    <div class="eachrelatedjob pt-2 pb-2 border-bottom">
                                        <a href="{{route('jobs.show', $rel->id)}}" class="text-success">{{$rel->title}}</a>
                                    </div>
                                    @php($counter++)
                                    @if($counter >= 10)
                                        @break
                                    @endif
                                @endforeach
                            @else
                                <h6>No Related Jobs</h6>
                            @endif
                        </fieldset>
                        
                    </div>
                    <div id="rightsidead1" class="pt-5">
                        <fieldset class="fieldsets p-3 rounded">
                            <legend class="w-auto pl-3 pr-3">Advertisement</legend>
                            <script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
                            <!-- 300*250 -->
                            <ins class="adsbygoogle"
                                style="display:inline-block;width:100%;height:250px"
                                data-ad-client="ca-pub-8480911180475311"
                                data-ad-slot="1676292648"></ins>
                            <script>
                                (adsbygoogle = window.adsbygoogle || []).push({});
                            </script>

                            
                            <script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
                            <!-- kar 300*600 -->
                            <ins class="adsbygoogle"
                                style="display:inline-block;width:100%;height:600px"
                                data-ad-client="ca-pub-8480911180475311"
                                data-ad-slot="3148731385"></ins>
                            <script>
                                (adsbygoogle = window.adsbygoogle || []).push({});
                            </script>
                        </fieldset>

                    </div>
                    <fieldset class="fieldsets p-3 rounded">
                        <legend class="w-auto pl-3 pr-3">Facebook</legend>
                        <iframe src="https://www.facebook.com/plugins/page.php?href=https%3A%2F%2Fwww.facebook.com%2Fkarmondana&tabs=timeline&width=340&height=500&small_header=false&adapt_container_width=true&hide_cover=false&show_facepile=true&appId" width="100%" height="200px" style="border:none;overflow:hidden" scrolling="no" frameborder="0" allowTransparency="true" allow="encrypted-media"></iframe>
                    </fieldset>
                
                </div>
            </div>
        </div>
    </section>
    <!-- Jobs Area End -->

    <div class="container">
        <div class="row">
            <div class="col-12">
                <script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
                <!-- karsq -->
                <ins class="adsbygoogle"
                    style="display:inline-block;width:720px;height:300px"
                    data-ad-client="ca-pub-8480911180475311"
                    data-ad-slot="6038209487"></ins>
                <script>
                    (adsbygoogle = window.adsbygoogle || []).push({});
                </script>
            </div>
        </div>
    </div>
    @endforeach


    @include('layout.footersection')
    <script src="{{asset('assets/js/vendor/sweetalert.min.js')}}"></script>
    <script>
        $('#locationsearch, #categorysearch').select2();

        function downloadfile(filepath){
                        $.ajax(
                            {
                                type:'POST',
                                url: "{{ url('/downloadfile') }}",
                                data: {_token: '{{csrf_token()}}', file:filepath},
                                success:function() {
                                        alert('123');
                                },
                                error:function(){
                                    swal("Oops!", "Unfortunately the attempt was not successful!", "error");
                                }

                            }
                        );
                    }
    </script>
    @include('layout.sessionmessage')
