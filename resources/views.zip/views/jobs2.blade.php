
    @include('layout.headingsectionwithoutimage')
    <link rel="stylesheet" href="{{asset('assets/css/nice-select.css')}}">
    <script data-ad-client="ca-pub-8480911180475311" async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
    <title>Jobs</title>
    <style>
        body {
            background: rgb(245,245,245);
        }
        body .jobs-area{
            font-size:13px;
        }

        .main-menu-light ul .nav-item .dropdown-item {
            color:white !important
        }


        .single-job{
            padding: 10px;
            box-shadow: 0 3px 5px rgba(0,0,0,0.1);
            background:white;
        }
        .single-job h6{
            cursor:pointer;
        }
        .fa-heart{
            transition: 0.4s ease;
        }
        .fa-heart:hover{
            color:crimson;
        }
        .select2{
            width:228px !important;
            height:auto;
            margin-top:8px;
        }
        .searchkeywordinput{
            line-height:47px;
            background:white;
            border: 1px solid #aaa;
            color:black;
        }

        .select2-container--default .select2-selection--single .select2-selection__arrow{
            height:0px;
        }



                /* Cosmetic only */
        .easyPaginateNav{
            margin:20px 0.25rem;
            text-align:center;
            width:100% !important;
            overflow:auto;
        }
        .easyPaginateNav a {
            padding:5px 10px;
            border: 1px solid lightgray;
            color:seagreen;
            border-radius: 2px;
            margin-left: 2px;
        }
        .easyPaginateNav a:hover{
            background: seagreen;
            color:white
        }
        .easyPaginateNav a.current {
            font-weight:bold;
            background:seagreen;
            color:white
        }
        .forcedispalynone{
            display:none !important;
        }






        @media (max-width: 991.98px) and (min-width: 768px)
        {
            .select2 {
                width: 150px !important;
            }
        }
        @media (max-width: 767.98px) and (min-width: 576px)
        {
            .select2{
                width:100% !important;
            }
            .search-bg form input{
                padding: 0 20px;
            }
        }
        @media (max-width: 575.98px)
        {
            .search-bg form input{
                padding: 0 20px;
            }

            .select2 {
                width: 100% !important;
            }
        }
    </style>
    @include('layout.fieldsets')
    @include('layout.globalfontsize')
    @include('layout.headersectionwithoutimage')

    <div class="page-title text-center">
        <div class="container">
            <div class="row">
                <div class="col-md-6 offset-md-3">
                    <h2>Job Search</h2>
                    <p class="lead">Now you can search jobs based on years of experience, education level and location</p>
                </div>
            </div>
        </div>
    </div>

    <!-- Search Area Starts -->
    <div class="search-area">
        <div class="search-bg">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
                        <!-- karsq -->
                        <ins class="adsbygoogle"
                            style="display:inline-block;width:100%;height:300px"
                            data-ad-client="ca-pub-8480911180475311"
                            data-ad-slot="6038209487"></ins>
                        <script>
                            (adsbygoogle = window.adsbygoogle || []).push({});
                        </script>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-12">
                        <form action="#" class="d-md-flex justify-content-between">
                            <select id="locationsearch">
                                <option value="" selected="selected">Select Location</option>
                                <option value="badakhshan">Badakhshan</option>
                                <option value="badghis" >Badghis</option>
                                <option value="baghlan">Baghlan</option>
                                <option value="balkh">Balkh</option>
                                <option value="bamyan">Bamyan</option>
                                <option value="daykundi">Daykundi</option>
                                <option value="farah">Farah</option>
                                <option value="faryab">Faryab</option>
                                <option value="ghazni">Ghazni</option>
                                <option value="ghor">Ghor</option>
                                <option value="helmand">Helmand</option>
                                <option value="herat">Herat</option>
                                <option value="jawzjan">Jawzjan</option>
                                <option value="kabul">Kabul</option>
                                <option value="kandahar">Kandahar</option>
                                <option value="kapisa">Kapisa</option>
                                <option value="khost">Khost</option>
                                <option value="kunar">Kunar</option>
                                <option value="kunduz">Kunduz</option>
                                <option value="laghman">Laghman</option>
                                <option value="logar">Logar</option>
                                <option value="nangarhar">Nangarhar</option>
                                <option value="nimroz">Nimroz</option>
                                <option value="nuristan">Nuristan</option>
                                <option value="uruzgan">Uruzgan</option>
                                <option value="parwan">Parwan</option>
                                <option value="paktia">Paktia</option>
                                <option value="paktika">Paktika</option>
                                <option value="panjshir">Panjshir</option>
                                <option value="samangan">Samangan</option>
                                <option value="sar-e-pul">Sar-e-Pul</option>
                                <option value="takhar">Takhar</option>
                                <option value="wardak">Wardak</option>
                                <option value="zabul">Zabul</option>
                            </select>
                            <select id="categorysearch">=
                                <option value="" selected="selected">Choose Category</option>
                                @foreach($categories as $cat)
                                <option value="{{$cat->id}}">{{$cat->name}}</option>
                                @endforeach
                            </select>
                            <input type="number" placeholder="Experience Years eg. 3" id="experiencesearch" class="single-input searchkeywordinput mt-2 border">
                            <button type="button" class="template-btn mt-2" style="background:#28a745" onclick="searchjob()">find job</button>
                        </form>
                    </div>
                </div>
                <div class="row">
                    <div class="col-12">
                        <script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
                        <!-- karsq -->
                        <ins class="adsbygoogle"
                            style="display:inline-block;width:100%;height:300px"
                            data-ad-client="ca-pub-8480911180475311"
                            data-ad-slot="6038209487"></ins>
                        <script>
                            (adsbygoogle = window.adsbygoogle || []).push({});
                        </script>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Search Area End -->

    <!-- Jobs Area Starts -->
    <section class="jobs-area section-padding">
        <div class="container">
            <div class="row">
                <div class="col-lg-9 col-md-8" id="">
                    @foreach($jobs as $job)
                    <div class="d-none hiddenjobs" id="jobhidden{{$job->id}}" data-id="{{$job->id}}">
                        <p class="d-none experiencecontainer">{{$job->experienceyears}}</p>
                        <p class="d-none categorycontainer">{{$job->category_id}}</p>
                        <p class="d-none locationcontainer">
                            @foreach($job->joblocation as $loc)
                                {{$loc->location}}
                            @endforeach
                        </p>
                    </div>
                    @endforeach
                    <div id="paginationdiv" class="paginationdiv">
                    @foreach($jobs as $job)
                        <div class="single-job border-bottom rounded p-3 d-flex" id="jobcontainer{{$job->id}}">
                            @if($job->company->user_id != 0)
                                <div class="pr-2">
                                    <img src="{{asset($job->company->user->avatar)}}" alt="job" width="40px" height="40px" class="rounded-circle mt-2">
                                </div>
                            @else
                            <div class="pr-2">
                                    <img src="{{asset('assets/avatars/company.png')}}" alt="job" width="40px" height="40px" class="rounded-circle mt-2">
                                </div>
                            @endif
                            <div class="job-text flex-fill">
                                <h6 class=""><a href="{{route('companyalljobs', $job->id)}}" class="text-secondary">{{str_limit($job->title, 25)}} <span class="badge badge-pill badge-success">{{$job->numberofjobs}}</span></a></h6>
                                <ul>
                                    <li Class="text-capitalize">
                                        {{str_limit($job->company->name, 20)}} | 
                                        @if(isset($job->joblocation[0]))
                                            @if(count($job->joblocation)>1)
                                                Multiple
                                            @else
                                                {{$job->joblocation[0]->location}}
                                            @endif
                                        @else
                                            Unavailable
                                        @endif
                                        | 
                                        <span class="text-danger">{{$job->closingdate}}</span>

                                        @if($job->gender == "male" or $job->gender == "female")
                                            <span class="float-right d-inline-block p-1 pr-3 pl-3 border border-secondary rounded">{{$job->gender}}</span>
                                        @endif

                                    </li>
                                </ul>
                            </div>
                        </div>
                    @endforeach
                    </div>
                </div>
                <div class="col-lg-3 col-md-4 shadow-sm p-2 mt-5 mt-md-0 rounded" id="jobdetailsrightside" style="background:white">
     
                    <div id="rightsidead1" class="">
                        <fieldset class="fieldsets p-3 rounded">
                            <legend class="w-auto pl-3 pr-3">Advertisement</legend>

                            <script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
                            <!-- 300*250 -->
                            <ins class="adsbygoogle"
                                style="display:inline-block;width:100%;height:250px"
                                data-ad-client="ca-pub-8480911180475311"
                                data-ad-slot="1676292648"></ins>
                            <script>
                                (adsbygoogle = window.adsbygoogle || []).push({});
                            </script>

                            
                            <script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
                            <!-- kar 300*600 -->
                            <ins class="adsbygoogle"
                                style="display:inline-block;width:100%;height:600px"
                                data-ad-client="ca-pub-8480911180475311"
                                data-ad-slot="3148731385"></ins>
                            <script>
                                (adsbygoogle = window.adsbygoogle || []).push({});
                            </script>

                        </fieldset>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <div class="container" >
        <div class="row">
            <div class="col-12">
                <script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
                <!-- karsq -->
                <ins class="adsbygoogle"
                    style="display:inline-block;width:100%;height:300px"
                    data-ad-client="ca-pub-8480911180475311"
                    data-ad-slot="6038209487"></ins>
                <script>
                    (adsbygoogle = window.adsbygoogle || []).push({});
                </script>
            </div>
        </div>
    </div>
    <!-- Jobs Area End -->


    @include('layout.footersection')
    <script src="{{asset('assets/js/vendor/sweetalert.min.js')}}"></script>
    <script src="{{asset('assets/js/vendor/jquery.easyPaginate.js')}}"></script>
    <script>
        var jsonjobs = {!!json_encode($jobs) !!};

        $('#locationsearch, #categorysearch').select2();
        $(document).ready(function(){
            paginatethis();
        });



        // $('#locationsearch, #categorysearch').on('change', function(){
        //     dosearch();
        // });

        // $('#experiencesearch').on('keyup', function(){
        //     dosearch();
        // });
        
        $('#serachbtn').on('click', function(){
            dosearch();
        });
        function dosearch(){
            $('#paginationdiv').empty();
            for(i = 0; i< jsonjobs.length; i++){
                if($('#experiencesearch') !=""){
                    if(! jsonjobs[i].experienceyears.toLowerCase().indexOf($('#experiencesearch').val())){
                        if(jsonjobs[i].company.user_id != 0){
                            var logo = jsonjobs[i].company.user.avatar;
                        }
                        else{
                            logo = 'assets/avatars/company.png';
                        }

                        if(jsonjobs[i].joblocation){
                           console.log(jsonjobs[i].joblocation[0])
                        }
                        else{
                            alert('there are no');
                        }


                        $('#paginationdiv').append('<div class="single-job border-bottom rounded p-3 d-flex" id="jobcontainer{{$job->id}}">'
                                                        +'<div class="pr-2">'
                                                            +'<img src="http://localhost/akbar/public/'+logo+'" alt="job" width="40px" height="40px" class="rounded-circle mt-2">'
                                                        +'</div>'
                                                        +'<div class="job-text flex-fill">'
                                                            +'<h6 class=""><a href="http://localhost/akbar/public/companyalljobs/'+jsonjobs[i].id+'" class="text-secondary">'+jsonjobs[i].title+' <span class="badge badge-pill badge-success">'+jsonjobs[i].numberofjobs+'</span></a></h6>'
                                                            +'<ul>'
                                                                +'<li Class="text-capitalize">'
                                                                    +jsonjobs[i].company.name+' | '
                                                                    +''
                                                        +'</div>'
                                                        
                                                    +'</div>');
                    }
                }
            }
        }   

    
        function paginatethis(){
            $('#paginationdiv').easyPaginate({
                paginateElement: '.single-job',
                elementsPerPage: 10,
                effect: 'climb',
                prevButtonText: 'Previous',
                nextButtonText:'Next',
                firstButtonText:'&laquo;',
                lastButtonText:'»'
            });
        }

    </script>
    @include('layout.sessionmessage')
