<style>
    .fieldsets{
            border: 1px solid green;
    }
    legend{
        font-size: 1.2rem;
        color:green
    }
</style>